import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "npm:@supabase/supabase-js@2.57.2";

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  // Get Stripe keys: api_keys table first (user-configured), then env var fallback
  let stripeKey = "";
  let webhookSecret = "";
  {
    const { data: keys } = await supabase.from("api_keys").select("key_name, key_value").in("key_name", ["STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET"]);
    if (keys) {
      for (const k of keys) {
        if (k.key_name === "STRIPE_SECRET_KEY") stripeKey = k.key_value;
        if (k.key_name === "STRIPE_WEBHOOK_SECRET") webhookSecret = k.key_value;
      }
    }
  }
  if (!stripeKey) stripeKey = Deno.env.get("STRIPE_SECRET_KEY") || "";
  if (!webhookSecret) webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET") || "";

  const stripe = new Stripe(stripeKey, {
    apiVersion: "2025-08-27.basil",
  });

  const signature = req.headers.get("stripe-signature");
  const body = await req.text();

  let event: Stripe.Event;
  try {
    if (!webhookSecret) {
      console.error("STRIPE_WEBHOOK_SECRET not configured");
      return new Response("Webhook secret not configured", { status: 500 });
    }
    event = await stripe.webhooks.constructEventAsync(body, signature!, webhookSecret);
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return new Response(`Webhook Error: ${err.message}`, { status: 400 });
  }

  // Idempotency check
  const { data: existing } = await supabase
    .from("stripe_webhook_events")
    .select("id")
    .eq("id", event.id)
    .maybeSingle();

  if (existing) {
    console.log(`Event ${event.id} already processed, skipping`);
    return new Response(JSON.stringify({ received: true }), { status: 200 });
  }

  await supabase.from("stripe_webhook_events").insert({ id: event.id });

  try {
    switch (event.type) {
      case "payment_intent.succeeded": {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        const metadata = paymentIntent.metadata || {};
        const checkoutId = metadata.checkout_id;

        if (!checkoutId) {
          console.log("No checkout_id in PI metadata, skipping");
          break;
        }

        // Audit log
        await supabase.from("audit_logs").insert({
          event_type: "payment_succeeded",
          payload: {
            payment_intent_id: paymentIntent.id,
            checkout_id: checkoutId,
            amount: paymentIntent.amount,
            customer_email: metadata.customer_email,
          },
        });

        await processSuccessfulPayment(supabase, stripe, {
          checkoutId,
          paymentIntentId: paymentIntent.id,
          customerId: typeof paymentIntent.customer === "string" ? paymentIntent.customer : null,
          paymentMethodId: typeof paymentIntent.payment_method === "string" ? paymentIntent.payment_method : null,
          customerEmail: metadata.customer_email || "",
          customerName: metadata.customer_name || "",
          customerPhone: metadata.customer_phone || "",
          selectedBumpIds: metadata.selected_bump_ids || "[]",
          utmSource: metadata.utm_source || null,
          utmMedium: metadata.utm_medium || null,
          utmCampaign: metadata.utm_campaign || null,
          utmContent: metadata.utm_content || null,
          utmTerm: metadata.utm_term || null,
        });
        break;
      }

      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const metadata = session.metadata || {};
        const checkoutId = metadata.checkout_id;

        if (!checkoutId) {
          console.log("No checkout_id in session metadata, skipping");
          break;
        }

        let paymentMethodId: string | null = null;
        let paymentIntentId: string | null = null;
        if (session.payment_intent) {
          paymentIntentId = session.payment_intent as string;
          try {
            const pi = await stripe.paymentIntents.retrieve(paymentIntentId);
            paymentMethodId = typeof pi.payment_method === "string" ? pi.payment_method : null;
          } catch (e) {
            console.warn("Failed to retrieve PI:", e);
          }
        }

        const stripeCustomerId = typeof session.customer === "string" ? session.customer : null;

        if (stripeCustomerId && paymentMethodId) {
          try {
            await stripe.customers.update(stripeCustomerId, {
              invoice_settings: { default_payment_method: paymentMethodId },
            });
          } catch (e) {
            console.warn("Failed to set default PM:", e);
          }
        }

        await processSuccessfulPayment(supabase, stripe, {
          checkoutId,
          paymentIntentId,
          customerId: stripeCustomerId,
          paymentMethodId,
          customerEmail: session.customer_email || session.customer_details?.email || "",
          customerName: metadata.customer_name || session.customer_details?.name || "",
          customerPhone: metadata.customer_phone || "",
          selectedBumpIds: metadata.selected_bump_ids || "[]",
          utmSource: metadata.utm_source || null,
          utmMedium: metadata.utm_medium || null,
          utmCampaign: metadata.utm_campaign || null,
          utmContent: metadata.utm_content || null,
          utmTerm: metadata.utm_term || null,
        });
        break;
      }

      case "payment_intent.payment_failed": {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        await supabase
          .from("orders")
          .update({ status: "failed" })
          .eq("stripe_payment_intent_id", paymentIntent.id);

        // Audit log
        await supabase.from("audit_logs").insert({
          event_type: "payment_failed",
          payload: {
            payment_intent_id: paymentIntent.id,
            error: paymentIntent.last_payment_error?.message || "unknown",
          },
        });

        console.log("Payment failed for:", paymentIntent.id);
        break;
      }

      case "charge.refunded": {
        const charge = event.data.object as any;
        const paymentIntentId = charge.payment_intent;
        if (paymentIntentId) {
          const { data: order } = await supabase
            .from("orders")
            .select("*, order_items(*, products(id, name, price, currency)), customers(name, email, phone)")
            .eq("stripe_payment_intent_id", paymentIntentId)
            .maybeSingle();

          if (order) {
            await supabase.from("orders").update({ status: "refunded" }).eq("id", order.id);

            await sendToUtmify(supabase, stripe, {
              orderId: order.id,
              paymentIntentId,
              status: "refunded",
              createdAt: order.created_at,
              approvedDate: order.created_at,
              refundedAt: new Date().toISOString(),
              paymentMethod: "credit_card",
              customer: {
                name: order.customers?.name || "",
                email: order.customers?.email || "",
                phone: order.customers?.phone || null,
                document: null,
              },
              products: (order.order_items || []).map((item: any) => ({
                id: item.products?.id || item.product_id,
                name: item.products?.name || "Product",
                priceInCents: item.amount,
                quantity: 1,
              })),
              trackingParameters: {
                src: null, sck: null,
                utm_source: order.utm_source, utm_campaign: order.utm_campaign,
                utm_medium: order.utm_medium, utm_content: order.utm_content, utm_term: order.utm_term,
              },
              totalAmountCents: order.total_amount,
              currency: order.currency || order.order_items?.[0]?.products?.currency || "eur",
            });

            await supabase.from("audit_logs").insert({
              event_type: "payment_refunded",
              payload: { payment_intent_id: paymentIntentId, order_id: order.id },
            });
          }
        }
        console.log("Charge refunded:", charge.id);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }
  } catch (error) {
    console.error("Error processing webhook:", error);
  }

  return new Response(JSON.stringify({ received: true }), {
    headers: { "Content-Type": "application/json" },
    status: 200,
  });
});

async function processSuccessfulPayment(
  supabase: any,
  stripe: any,
  params: {
    checkoutId: string;
    paymentIntentId: string | null;
    customerId: string | null;
    paymentMethodId: string | null;
    customerEmail: string;
    customerName: string;
    customerPhone: string;
    selectedBumpIds: string;
    utmSource: string | null;
    utmMedium: string | null;
    utmCampaign: string | null;
    utmContent: string | null;
    utmTerm: string | null;
  }
) {
  const {
    checkoutId, paymentIntentId, customerId, paymentMethodId,
    customerEmail, customerName, customerPhone, selectedBumpIds,
    utmSource, utmMedium, utmCampaign, utmContent, utmTerm,
  } = params;

  const { data: checkout } = await supabase
    .from("checkouts")
    .select("*, products!checkouts_product_id_fkey(id, name, price, currency), first_offer_id")
    .eq("id", checkoutId)
    .single();

  if (!checkout) {
    console.error("Checkout not found:", checkoutId);
    return;
  }

  let { data: customer } = await supabase
    .from("customers")
    .select("*")
    .eq("email", customerEmail)
    .maybeSingle();

  if (!customer) {
    const { data: newCustomer } = await supabase
      .from("customers")
      .insert({
        name: customerName,
        email: customerEmail,
        phone: customerPhone || null,
        stripe_customer_id: customerId,
        stripe_payment_method_id: paymentMethodId,
      })
      .select()
      .single();
    customer = newCustomer;
  } else {
    const updates: Record<string, any> = {};
    if (customerId && !customer.stripe_customer_id) updates.stripe_customer_id = customerId;
    if (paymentMethodId) updates.stripe_payment_method_id = paymentMethodId;
    if (Object.keys(updates).length > 0) {
      await supabase.from("customers").update(updates).eq("id", customer.id);
    }
  }

  if (!customer) {
    console.error("Failed to create/find customer");
    return;
  }

  if (paymentIntentId) {
    const { data: existingOrder } = await supabase
      .from("orders")
      .select("id")
      .eq("stripe_payment_intent_id", paymentIntentId)
      .maybeSingle();

    if (existingOrder) {
      console.log("Order already exists for this payment intent, skipping");
      return;
    }
  }

  let totalAmount = checkout.products.price;
  let bumpProductIds: string[] = [];
  try { bumpProductIds = JSON.parse(selectedBumpIds); } catch { bumpProductIds = []; }

  let bumpProducts: any[] = [];
  if (bumpProductIds.length > 0) {
    const { data: bps } = await supabase
      .from("products")
      .select("id, name, price")
      .in("id", bumpProductIds);
    bumpProducts = bps || [];
    for (const bp of bumpProducts) totalAmount += bp.price;
  }

  const orderCurrency = (checkout.products.currency || "eur").toUpperCase();

  const { data: order, error: orderError } = await supabase
    .from("orders")
    .insert({
      customer_id: customer.id,
      checkout_id: checkout.id,
      total_amount: totalAmount,
      currency: orderCurrency,
      status: "paid",
      stripe_payment_intent_id: paymentIntentId,
      utm_source: utmSource,
      utm_medium: utmMedium,
      utm_campaign: utmCampaign,
      utm_content: utmContent,
      utm_term: utmTerm,
    })
    .select()
    .single();

  if (orderError) {
    console.error("Failed to create order:", orderError);
    return;
  }

  const items: any[] = [
    { order_id: order.id, product_id: checkout.products.id, amount: checkout.products.price, type: "main" },
  ];
  for (const bp of bumpProducts) {
    items.push({ order_id: order.id, product_id: bp.id, amount: bp.price, type: "bump" });
  }

  const { data: insertedItems } = await supabase.from("order_items").insert(items).select("id, product_id");

  // Mark abandoned checkout as recovered
  await supabase
    .from("abandoned_checkouts")
    .update({ recovered: true })
    .eq("checkout_id", checkout.id)
    .eq("email", customerEmail);

  // Create first offer session if configured
  if (checkout.first_offer_id && customer.id) {
    const { data: offerSession } = await supabase
      .from("offer_sessions")
      .insert({
        offer_id: checkout.first_offer_id,
        order_id: order.id,
        customer_id: customer.id,
      })
      .select("token")
      .single();

    if (offerSession) {
      console.log("Offer session created:", offerSession.token);
    }
  }

  // Set default payment method on Stripe customer
  if (customerId && paymentMethodId) {
    try {
      await stripe.customers.update(customerId, {
        invoice_settings: { default_payment_method: paymentMethodId },
      });
    } catch (e) {
      console.warn("Failed to set default payment method:", e);
    }
  }

  // Trigger deliveries for all order items
  if (insertedItems && insertedItems.length > 0) {
    for (const item of insertedItems) {
      try {
        const deliveryUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/delivery-send`;
        await fetch(deliveryUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
          },
          body: JSON.stringify({ order_id: order.id, order_item_id: item.id }),
        });
      } catch (e) {
        console.warn("Failed to trigger delivery for item:", item.id, e);
      }
    }
  }

  // Send to Utmify
  await sendToUtmify(supabase, stripe, {
    orderId: order.id,
    paymentIntentId,
    status: "paid",
    createdAt: order.created_at,
    approvedDate: order.created_at,
    refundedAt: null,
    paymentMethod: "credit_card",
    customer: {
      name: customerName,
      email: customerEmail,
      phone: customerPhone || null,
      document: null,
    },
    products: [
      { id: checkout.products.id, name: checkout.products.name, priceInCents: checkout.products.price, quantity: 1 },
      ...bumpProducts.map((bp: any) => ({ id: bp.id, name: bp.name || "Bump", priceInCents: bp.price, quantity: 1 })),
    ],
    trackingParameters: {
      src: null, sck: null,
      utm_source: utmSource, utm_campaign: utmCampaign, utm_medium: utmMedium,
      utm_content: utmContent, utm_term: utmTerm,
    },
    totalAmountCents: totalAmount,
    currency: order.currency || checkout.products.currency || "eur",
  });

  console.log("Order created successfully:", order.id);
}

// ── Utmify Integration ──────────────────────────────────────────────

async function getUtmifyApiKey(supabase: any): Promise<string | null> {
  const { data } = await supabase
    .from("api_keys")
    .select("key_value")
    .eq("key_name", "UTMIFY_API_KEY")
    .maybeSingle();
  if (data?.key_value) return data.key_value;
  return Deno.env.get("UTMIFY_API_KEY") || null;
}

function formatUtcDate(isoDate: string): string {
  const d = new Date(isoDate);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

interface UtmifyParams {
  orderId: string;
  paymentIntentId: string | null;
  status: "waiting_payment" | "paid" | "refused" | "refunded" | "chargedback";
  createdAt: string;
  approvedDate: string | null;
  refundedAt: string | null;
  paymentMethod: "credit_card" | "boleto" | "pix" | "paypal" | "free_price";
  customer: { name: string; email: string; phone: string | null; document: string | null };
  products: { id: string; name: string; priceInCents: number; quantity: number }[];
  trackingParameters: {
    src: string | null; sck: string | null;
    utm_source: string | null; utm_campaign: string | null; utm_medium: string | null;
    utm_content: string | null; utm_term: string | null;
  };
  totalAmountCents: number;
  currency: string;
}

const UTMIFY_SUPPORTED_CURRENCIES = new Set([
  "BRL", "USD", "EUR", "GBP", "ARS", "CAD", "COP", "MXN",
  "PYG", "CLP", "PEN", "PLN", "UAH", "CHF", "THB", "AUD",
]);

async function getEurAmountFromBalanceTransaction(
  stripe: Stripe,
  paymentIntentId: string | null,
): Promise<number | null> {
  if (!paymentIntentId) return null;

  try {
    const pi = await stripe.paymentIntents.retrieve(paymentIntentId, {
      expand: ["latest_charge.balance_transaction"],
    } as any);

    const latestCharge = pi.latest_charge;
    if (!latestCharge || typeof latestCharge === "string") return null;

    const balanceTxRaw = latestCharge.balance_transaction;
    if (!balanceTxRaw) return null;

    let balanceTx: Stripe.BalanceTransaction;
    if (typeof balanceTxRaw === "string") {
      balanceTx = await stripe.balanceTransactions.retrieve(balanceTxRaw);
    } else {
      balanceTx = balanceTxRaw;
    }

    if (balanceTx.currency?.toUpperCase() !== "EUR") return null;

    const eurAmount = Math.abs(balanceTx.amount ?? 0);
    return eurAmount > 0 ? eurAmount : null;
  } catch (error) {
    console.warn("Could not resolve EUR amount from balance transaction:", error);
    return null;
  }
}

async function getEurAmountFromStripeExchangeRate(
  stripe: Stripe,
  sourceCurrency: string,
  sourceAmountInCents: number,
): Promise<{ amountInCents: number; rate: number } | null> {
  if (!sourceAmountInCents || sourceAmountInCents <= 0) return null;

  try {
    const fx = await stripe.exchangeRates.retrieve(sourceCurrency.toLowerCase());
    const eurRate = fx?.rates?.eur;

    if (typeof eurRate !== "number" || eurRate <= 0) return null;

    const converted = Math.round(sourceAmountInCents * eurRate);
    if (converted <= 0) return null;

    return { amountInCents: converted, rate: eurRate };
  } catch (error) {
    console.warn("Could not resolve EUR amount from Stripe exchange rates:", error);
    return null;
  }
}

function convertProductsToTargetCurrency(
  products: UtmifyParams["products"],
  conversionRate: number,
  targetTotalInCents: number,
): UtmifyParams["products"] {
  if (!products.length) return products;

  const converted = products.map((product) => ({
    ...product,
    priceInCents: Math.max(0, Math.round(product.priceInCents * conversionRate)),
  }));

  let diff = targetTotalInCents - converted.reduce((sum, product) => sum + product.priceInCents, 0);
  let guard = 0;

  while (diff !== 0 && guard < 5000) {
    const idx = guard % converted.length;
    const delta = diff > 0 ? 1 : -1;
    const next = converted[idx].priceInCents + delta;

    if (next >= 0) {
      converted[idx].priceInCents = next;
      diff -= delta;
    }

    guard++;
  }

  return converted;
}

async function sendToUtmify(supabase: any, stripe: Stripe, params: UtmifyParams) {
  const apiKey = await getUtmifyApiKey(supabase);
  if (!apiKey) {
    console.log("Utmify API key not configured, skipping");
    return;
  }

  const sourceCurrency = (params.currency || "EUR").toUpperCase();
  let targetCurrency = sourceCurrency;
  let targetAmountInCents = params.totalAmountCents;
  let productAmounts = params.products;

  if (!UTMIFY_SUPPORTED_CURRENCIES.has(sourceCurrency)) {
    let conversionRate = 0;

    const amountFromBalance = await getEurAmountFromBalanceTransaction(stripe, params.paymentIntentId);
    if (amountFromBalance && params.totalAmountCents > 0) {
      targetCurrency = "EUR";
      targetAmountInCents = amountFromBalance;
      conversionRate = amountFromBalance / params.totalAmountCents;
    } else {
      const amountFromFx = await getEurAmountFromStripeExchangeRate(stripe, sourceCurrency, params.totalAmountCents);
      if (amountFromFx) {
        targetCurrency = "EUR";
        targetAmountInCents = amountFromFx.amountInCents;
        conversionRate = amountFromFx.rate;
      }
    }

    if (targetCurrency !== "EUR" || conversionRate <= 0) {
      console.error("Utmify skipped: unsupported currency without EUR conversion", {
        orderId: params.orderId,
        sourceCurrency,
        totalAmountCents: params.totalAmountCents,
      });

      await supabase.from("audit_logs").insert({
        event_type: "utmify_skipped_unsupported_currency",
        payload: {
          order_id: params.orderId,
          payment_intent_id: params.paymentIntentId,
          source_currency: sourceCurrency,
          source_amount_in_cents: params.totalAmountCents,
        },
      });
      return;
    }

    productAmounts = convertProductsToTargetCurrency(params.products, conversionRate, targetAmountInCents);

    console.log("Utmify currency converted", {
      orderId: params.orderId,
      sourceCurrency,
      sourceAmountInCents: params.totalAmountCents,
      targetCurrency,
      targetAmountInCents,
    });

    await supabase.from("audit_logs").insert({
      event_type: "utmify_currency_converted",
      payload: {
        order_id: params.orderId,
        payment_intent_id: params.paymentIntentId,
        source_currency: sourceCurrency,
        source_amount_in_cents: params.totalAmountCents,
        target_currency: targetCurrency,
        target_amount_in_cents: targetAmountInCents,
      },
    });
  }

  const payload = {
    orderId: params.orderId,
    platform: "Yocota",
    paymentMethod: params.paymentMethod,
    status: params.status,
    createdAt: formatUtcDate(params.createdAt),
    approvedDate: params.approvedDate ? formatUtcDate(params.approvedDate) : null,
    refundedAt: params.refundedAt ? formatUtcDate(params.refundedAt) : null,
    customer: {
      name: params.customer.name,
      email: params.customer.email,
      phone: params.customer.phone,
      document: params.customer.document,
    },
    products: productAmounts.map((p) => ({
      id: p.id,
      name: p.name,
      planId: null,
      planName: null,
      quantity: p.quantity,
      priceInCents: p.priceInCents,
    })),
    trackingParameters: params.trackingParameters,
    commission: {
      totalPriceInCents: targetAmountInCents,
      gatewayFeeInCents: 0,
      userCommissionInCents: targetAmountInCents,
      currency: targetCurrency,
    },
  };

  try {
    const resp = await fetch("https://api.utmify.com.br/api-credentials/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-token": apiKey,
      },
      body: JSON.stringify(payload),
    });
    const text = await resp.text();
    if (!resp.ok) {
      console.error("Utmify API error:", resp.status, text);
    } else {
      console.log("Utmify order sent:", params.orderId, params.status);
    }
  } catch (e) {
    console.warn("Failed to send to Utmify:", e);
  }
}
